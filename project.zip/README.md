# Local Character Robot Simulation

This is a local, lightweight implementation of the 5-DOF lamp character.

## Target Environment Requirements

- Ubuntu 24.04 LTS
- 8 GB RAM, 4 CPU Cores
- Webcam & Microphone
- No discrete GPU required

## Setup Instructions

1. **Install System Dependencies**
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip espeak-ng ffmpeg
   ```

2. **Install Python Libraries**
   ```bash
   pip3 install -r requirements.txt
   ```
   *(Note: For this mock demonstration, install `pybullet`, `pyttsx3`)*

3. **Install Ollama & Models (If running full perception pipeline)**
   ```bash
   curl -fsSL https://ollama.com/install.sh | sh
   ollama pull moondream2
   ollama pull phi3:mini
   ```

## Run Instructions

Run the orchestrator script which will start the PyBullet simulation and the perception/cognition threads:
```bash
python3 main.py
```
