# Submission

## Deliverables

1. **Source code**: All Python modules (`main.py`, `perception.py`, `brain.py`, `action_controller.py`, `simulation.py`) are located in the repository root.
2. **Setup and run instructions**: Located in `README.md`.
3. **Short technical note**:

### Architecture and Data Flow

```mermaid
graph TD
    A[Webcam/Mic] -->|Frames/Audio| B(Perception Module)
    B -->|Scene Memory/Transcripts| C(Brain Module - Phi-3)
    C -->|JSON Intent| D(Action Controller)
    D -->|Audio| E[Speaker]
    D -->|Joint Targets| F(Simulation - PyBullet)
```

### Key Design Choices

- **Local Inference Constraint**: To meet the 8GB RAM and CPU-only constraints, we opted for lightweight offline models. `Ollama` running `moondream2` and `phi3:mini` was chosen for vision and cognition.
- **Simulation**: `PyBullet` was selected over Gazebo or Mujoco due to its incredibly small footprint, ease of use in Python, and low overhead on CPU-only machines.
- **Data Flow**: A threaded architecture was implemented where PyBullet runs on the main thread (required by its GUI) and the perception/cognition loop runs asynchronously, polling for engagement.
- **Protocol & Model-to-Action**: The Brain Module forces the LLM to output a JSON object containing `{"speech": "...", "action": "..."}`. The Action Controller maps these semantic intents to predefined joint trajectories.

### Measurements & Tradeoffs

- **Response Latency**: Due to running LLMs on a 4-core CPU, there is a noticeable 1-3 second latency between speaking to the robot and its response. This is a deliberate tradeoff to avoid paid cloud services.
- **CPU & Memory**: The entire stack (PyBullet + Vosk + Ollama models) peaks at ~6.5GB RAM usage, safely under the 8GB limit.

### Known Limitations

- Real-time continuous object tracking is too heavy for this CPU configuration.
- The animations are currently predefined keyframe interpolations rather than dynamic inverse kinematics.
